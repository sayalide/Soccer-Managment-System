import pandas as pd
import mysql.connector as msql

conn = msql.connect(host='localhost', user='root', password='Sayali19', database='Soccer')
cursor = conn.cursor()
cursor.execute("select Soccer()")
record = cursor.fetchall()
print("connected", "records")


def Card():
    data = pd.read_csv('C:/Users/sayalideshmukh/Desktop/PLAYER_CARD.csv', index_col=False, delimiter=',')
    data.head()
    for i, row in data.iterrows():
        sql = "INSERT INTO PLAYER_CARD VALUES (%s,%s,%s)"
        cursor.execute(sql, tuple(row))
        print("Successfully inserted the records of PLAYER_CARD")
        cursor.close()
        conn.commit()
        conn.close()
