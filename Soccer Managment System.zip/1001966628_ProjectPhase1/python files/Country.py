import pandas as pd
import mysql.connector as msql

conn = msql.connect(host='localhost', user='root', password='Sayali19', database='Soccer')
cursor = conn.cursor()
cursor.execute("select Soccer()")
record = cursor.fetchall()
print("connected", "records")


def Country():
    data = pd.read_csv('C:/Users/sayalideshmukh/Desktop/Country.csv', index_col=False, delimiter=',')
    data.head()
    for i, row in data.iterrows():
        sql = "INSERT INTO country VALUES (%s,%s,%s,%s)"
        cursor.execute(sql, tuple(row))
        print("Successfully inserted the records of Country")
        cursor.close()
        conn.commit()
        conn.close()
