import pandas as pd
import mysql.connector as msql

conn = msql.connect(host='localhost', user='root', password='Sayali19', database='Soccer')
cursor = conn.cursor()
cursor.execute("select Soccer()")
record = cursor.fetchall()
print("connected", "records")


def Results():
    data = pd.read_csv('C:/Users/sayalideshmukh/Desktop/Match_results.csv', index_col=False, delimiter=',')
    data.head()
    for i, row in data.iterrows():
        sql = "INSERT INTO Match_results VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)"
        cursor.execute(sql, tuple(row))
        print("Successfully inserted the records of Match_results")
        cursor.close()
        conn.commit()
        conn.close()
