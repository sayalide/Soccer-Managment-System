import pandas as pd
import myssql.connector as msql

conn = msql.connect(host='localhost', user='root', password='Sayali19', database='Soccer')
cursor = conn.cursor()
cursor.execute("select Soccer()")
record = cursor.fetchall()
print("connected", "records")


def Players():
    data = pd.read_csv('C:/Users/sayalideshmukh/Desktop/Players.csv', index_col=False, delimiter=',')
    data.head()
    for i, row in data.iterrows():
        sql = "INSERT INTO Players VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
        cursor.execute(sql, tuple(row))
        print("Successfully inserted the records of Players")
        cursor.close()
        conn.commit()
        conn.close()
